/* Automation Studio generated header file */
/* Do not edit ! */

#ifndef _BUR_1700835785_3_
#define _BUR_1700835785_3_

#include <bur/plctypes.h>




__asm__(".section \".plc\"");

/* Used IEC files */
__asm__(".ascii \"iecfile \\\"Logical/Program/Types.typ\\\" scope \\\"local\\\"\\n\"");

/* Exported library functions and function blocks */

__asm__(".previous");


#endif /* _BUR_1700835785_3_ */

